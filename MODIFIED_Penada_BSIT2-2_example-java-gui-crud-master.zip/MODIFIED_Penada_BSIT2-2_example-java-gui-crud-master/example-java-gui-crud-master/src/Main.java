import pages.LoginPage;

import javax.swing.*;

public class Main { //added sign up page to add new user credentials
    public static void main(String[] args) {

        SwingUtilities.invokeLater(LoginPage::new);
    }

}